package com.myshort.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    private val homeUrl = "https://myshort-b3o.github.io/"

    private val trustedHosts = setOf(
        "myshort-b3o.github.io",
        "myshort-b3o.pages.dev",
        "myshort-b3o.servernet6666.workers.dev",
        "shortprodly.github.io"
    )

    private val downloadPermissionRequestCode = 7001

    private val downloadBridge = object {
        @JavascriptInterface
        fun saveBase64File(fileName: String?, dataUrl: String?): Boolean {
            if (dataUrl.isNullOrBlank()) return false

            return try {
                val safeName = sanitizeFileName(
                    if (fileName.isNullOrBlank()) "MyShort_Download.png" else fileName
                )
                val comma = dataUrl.indexOf(',')
                if (comma < 0) return false

                val header = dataUrl.substring(0, comma)
                val payload = dataUrl.substring(comma + 1)

                val bytes = if (header.contains(";base64", ignoreCase = true)) {
                    Base64.decode(payload, Base64.DEFAULT)
                } else {
                    URLDecoder.decode(payload, "UTF-8").toByteArray(Charsets.UTF_8)
                }

                saveBytesToDownloads(safeName, bytes)
            } catch (_: Exception) {
                false
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progress = findViewById(R.id.progress)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = false
        }

        webView.addJavascriptInterface(downloadBridge, "AndroidDownloader")

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val uri = Uri.parse(url)
                if (uri.scheme == "http" || uri.scheme == "https") {
                    val request = android.app.DownloadManager.Request(uri)
                    request.setMimeType(mimeType ?: "application/octet-stream")
                    if (!userAgent.isNullOrBlank()) {
                        request.addRequestHeader("User-Agent", userAgent)
                    }
                    request.setTitle(contentDisposition ?: "MyShort Download")
                    request.setDescription("Mengunduh file dari MyShort")
                    request.setNotificationVisibility(
                        android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    )
                    request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        safeDownloadName(contentDisposition ?: "MyShort_Download")
                    )
                    val manager = getSystemService(Context.DOWNLOAD_SERVICE)
                            as android.app.DownloadManager
                    manager.enqueue(request)
                    Toast.makeText(this, "Download dimulai", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "Download gagal", Toast.LENGTH_SHORT).show()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.visibility = if (newProgress < 95) View.VISIBLE else View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                return when (scheme) {
                    "http", "https" -> false
                    else -> {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                        } catch (_: Exception) {}
                        true
                    }
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE

                val host = try {
                    Uri.parse(url ?: "").host?.lowercase()
                } catch (_: Exception) {
                    null
                }

                if (host != null && trustedHosts.contains(host)) {
                    webView.evaluateJavascript(DOWNLOAD_INTERCEPT_SCRIPT, null)
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl(homeUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun saveBytesToDownloads(fileName: String, bytes: ByteArray): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, guessMimeType(fileName))
                    put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/MyShort"
                    )
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }

                val uri = resolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
                ) ?: return false

                try {
                    resolver.openOutputStream(uri).use { output ->
                        if (output == null) throw IllegalStateException("Output stream null")
                        output.write(bytes)
                        output.flush()
                    }

                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)

                    runOnUiThread {
                        Toast.makeText(
                            this,
                            "Bukti tersimpan di Download/MyShort",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    true
                } catch (_: Exception) {
                    resolver.delete(uri, null, null)
                    false
                }
            } else {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            "Izinkan akses penyimpanan lalu tekan DOWNLOAD lagi",
                            Toast.LENGTH_LONG
                        ).show()
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                            downloadPermissionRequestCode
                        )
                    }
                    false
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    )
                    val myShortDir = File(dir, "MyShort")
                    if (!myShortDir.exists()) myShortDir.mkdirs()

                    File(myShortDir, fileName).let { file ->
                        FileOutputStream(file).use { it.write(bytes) }
                    }

                    runOnUiThread {
                        Toast.makeText(
                            this,
                            "Bukti tersimpan di Download/MyShort",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    true
                }
            }
        } catch (_: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_SHORT).show()
            }
            false
        }
    }

    private fun sanitizeFileName(name: String): String {
        val cleaned = name
            .replace(Regex("""[\\/:*?"<>|]"""), "_")
            .trim()
        return if (cleaned.isBlank()) "MyShort_Download.png" else cleaned.take(120)
    }

    private fun safeDownloadName(contentDisposition: String): String {
        val match = Regex(
            """filename\s*=\s*([^;]+)""",
            RegexOption.IGNORE_CASE
        ).find(contentDisposition)
        val raw = match?.groupValues?.getOrNull(1)?.trim()?.trim('"')
            ?: "MyShort_Download"
        return sanitizeFileName(raw)
    }

    private fun guessMimeType(fileName: String): String {
        return when {
            fileName.endsWith(".png", true) -> "image/png"
            fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) -> "image/jpeg"
            fileName.endsWith(".pdf", true) -> "application/pdf"
            else -> "application/octet-stream"
        }
    }

    companion object {
        private const val DOWNLOAD_INTERCEPT_SCRIPT = """
            (function () {
                if (window.__myshortDownloadBridgeInstalled) return;
                window.__myshortDownloadBridgeInstalled = true;

                function sendToAndroid(name, href) {
                    if (!window.AndroidDownloader || !href) return false;

                    if (href.indexOf('data:') === 0) {
                        try {
                            window.AndroidDownloader.saveBase64File(
                                name || 'MyShort_Download.png',
                                href
                            );
                            return true;
                        } catch (e) {
                            return false;
                        }
                    }

                    if (href.indexOf('blob:') === 0) {
                        fetch(href)
                            .then(function (response) { return response.blob(); })
                            .then(function (blob) {
                                var reader = new FileReader();
                                reader.onloadend = function () {
                                    try {
                                        window.AndroidDownloader.saveBase64File(
                                            name || 'MyShort_Download.png',
                                            reader.result
                                        );
                                    } catch (e) {}
                                };
                                reader.readAsDataURL(blob);
                            })
                            .catch(function () {});
                        return true;
                    }

                    return false;
                }

                document.addEventListener('click', function (event) {
                    var target = event.target;
                    if (!target || !target.closest) return;

                    var anchor = target.closest('a[download]');
                    if (!anchor) return;

                    var href = anchor.getAttribute('href') || '';
                    if (href.indexOf('data:') === 0 || href.indexOf('blob:') === 0) {
                        event.preventDefault();
                        event.stopPropagation();
                        sendToAndroid(
                            anchor.getAttribute('download') || 'MyShort_Download.png',
                            href
                        );
                    }
                }, true);
            })();
        """
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
}
