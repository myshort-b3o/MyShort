# MyShort Android

Aplikasi Android WebView untuk MyShort.

- Nama aplikasi: MyShort
- Application ID: `com.myshort.app`
- URL: `https://shortprodly.github.io/`
- Minimum Android: 6 (API 23)
- Target Android: 15 (API 35)

Catatan: Android mewajibkan application ID yang memiliki minimal dua bagian yang dipisahkan titik, sehingga `myshort` saja tidak valid sebagai application ID. Karena itu digunakan `com.myshort.app`.
