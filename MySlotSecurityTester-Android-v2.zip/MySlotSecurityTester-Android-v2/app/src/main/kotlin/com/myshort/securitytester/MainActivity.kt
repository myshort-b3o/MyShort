package com.myshort.securitytester

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private lateinit var endpointInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var betInput: EditText
    private lateinit var resultView: TextView
    private lateinit var progress: ProgressBar

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val requestCount = AtomicInteger(0)
    private val maxRequests = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(createUi())
    }

    private fun createUi(): ScrollView {
        val scroll = ScrollView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "MySlot Security Tester"
            textSize = 25f
        })

        root.addView(TextView(this).apply {
            text = "Android v2 • Authorized testing only"
            textSize = 13f
        })

        root.addView(TextView(this).apply {
            text = "HTTPS endpoint"
            textSize = 14f
        })

        endpointInput = EditText(this).apply {
            hint = "https://server-anda.example/api/spin"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            singleLine = true
        }
        root.addView(endpointInput)

        root.addView(TextView(this).apply {
            text = "Bearer token akun TEST"
            textSize = 14f
        })

        tokenInput = EditText(this).apply {
            hint = "Token (opsional)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
        }
        root.addView(tokenInput)

        root.addView(TextView(this).apply {
            text = "Nominal bet"
            textSize = 14f
        })

        betInput = EditText(this).apply {
            setText("1000")
            inputType = InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        root.addView(betInput)

        addButton(root, "JALANKAN SEMUA TEST") {
            runTests(listOf("tamper", "replay", "auth"))
        }

        addButton(root, "TEST PARAMETER TAMPERING") {
            runTests(listOf("tamper"))
        }

        addButton(root, "TEST REPLAY") {
            runTests(listOf("replay"))
        }

        addButton(root, "TEST AUTHENTICATION") {
            runTests(listOf("auth"))
        }

        progress = ProgressBar(this).apply {
            visibility = View.GONE
        }
        root.addView(progress)

        resultView = TextView(this).apply {
            text = "Hasil pengujian akan tampil di sini."
            textSize = 13f
            setPadding(0, 24, 0, 24)
        }
        root.addView(resultView)

        root.addView(TextView(this).apply {
            text = "PERINGATAN: gunakan hanya server milik Anda/yang memberi izin dan akun TEST. Tool dibatasi maksimal 12 request per sesi."
            textSize = 12f
        })

        scroll.addView(root)
        return scroll
    }

    private fun addButton(
        root: LinearLayout,
        text: String,
        action: () -> Unit
    ) {
        root.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        })
    }

    private fun runTests(tests: List<String>) {
        val endpoint = endpointInput.text.toString().trim()

        if (!endpoint.startsWith("https://")) {
            toast("Endpoint harus HTTPS.")
            return
        }

        requestCount.set(0)
        resultView.text = ""
        progress.visibility = View.VISIBLE

        scope.launch {
            try {
                for (test in tests) {
                    when (test) {
                        "tamper" -> testTampering(endpoint)
                        "replay" -> testReplay(endpoint)
                        "auth" -> testAuthentication(endpoint)
                    }
                }
            } catch (e: Exception) {
                appendResult("ERROR: ${e.message}")
            } finally {
                progress.visibility = View.GONE
                appendResult("Requests: ${requestCount.get()}/$maxRequests")
            }
        }
    }

    private suspend fun testTampering(endpoint: String) {
        appendResult("\n=== PARAMETER TAMPERING ===")

        val tests = listOf(
            "win" to 100000000,
            "payout" to 100000000,
            "balance" to 999999999,
            "result" to "JACKPOT"
        )

        for ((key, value) in tests) {
            if (requestCount.get() >= maxRequests) break

            val payload = JSONObject()
                .put("bet", readBet())
                .put(key, value)

            val response = post(endpoint, payload, true)

            if (response == null) {
                appendResult("WARN $key: request gagal")
                continue
            }

            if (response.code in setOf(400, 401, 403, 409, 422)) {
                appendResult("PASS $key: server menolak HTTP ${response.code}")
            } else {
                appendResult(
                    "WARN $key: server tidak menolak HTTP ${response.code}. " +
                        "Verifikasi log/database bahwa nilai tersebut tidak dipercaya."
                )
            }
        }
    }

    private suspend fun testReplay(endpoint: String) {
        appendResult("\n=== REPLAY ===")

        val payload = JSONObject().put("bet", readBet())

        val first = post(endpoint, payload, true)
        val second = post(endpoint, payload, true)

        if (first == null || second == null) {
            appendResult("WARN replay: request gagal")
            return
        }

        if (second.code == 409 || second.code == 429) {
            appendResult("PASS replay: request kedua ditolak HTTP ${second.code}")
        } else {
            appendResult(
                "WARN replay: request kedua mendapat HTTP ${second.code}. " +
                    "Pastikan server memiliki idempotency/replay protection."
            )
        }
    }

    private suspend fun testAuthentication(endpoint: String) {
        appendResult("\n=== AUTHENTICATION ===")

        val payload = JSONObject().put("bet", readBet())
        val response = post(endpoint, payload, false)

        if (response == null) {
            appendResult("WARN auth: request gagal")
            return
        }

        if (response.code == 401 || response.code == 403) {
            appendResult("PASS auth: tanpa token ditolak HTTP ${response.code}")
        } else {
            appendResult(
                "FAIL auth: endpoint menerima request tanpa token HTTP ${response.code}"
            )
        }
    }

    private suspend fun post(
        endpoint: String,
        payload: JSONObject,
        includeAuth: Boolean
    ): ResponseData? = withContext(Dispatchers.IO) {

        if (requestCount.incrementAndGet() > maxRequests) {
            return@withContext null
        }

        try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 10_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")

                if (includeAuth) {
                    val token = tokenInput.text.toString().trim()
                    if (token.isNotEmpty()) {
                        setRequestProperty("Authorization", "Bearer $token")
                    }
                }
            }

            connection.outputStream.use { output ->
                output.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            connection.disconnect()

            ResponseData(code)
        } catch (_: Exception) {
            null
        }
    }

    private fun readBet(): Long {
        return betInput.text.toString().toLongOrNull()?.coerceAtLeast(1L) ?: 1000L
    }

    private fun appendResult(message: String) {
        runOnUiThread {
            resultView.append("$message\n")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    data class ResponseData(val code: Int)
}
