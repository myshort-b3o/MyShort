# MySlot Security Tester Android v2

Android native Kotlin project for authorized security testing of a game API you own or are explicitly permitted to test.

## GitHub Actions

1. Upload the project to GitHub.
2. Push to the `main` branch or open:
   **Actions → Build MyShort APK → Run workflow**
3. Wait for the green build.
4. Open the workflow result.
5. Download artifact:
   `MySlot-Security-Tester-v2-debug`
6. Extract the artifact and install `app-debug.apk`.

## Why v2

The workflow was simplified to avoid depending on a Gradle Wrapper uploaded with the project. GitHub Actions installs Gradle 8.10.2 directly, uses JDK 17, Ubuntu 24.04, Android SDK 35, and prints full Gradle stack traces when a build fails.

## Tests

- Parameter tampering
- Replay
- Authentication
- HTTPS-only target
- Maximum 12 requests per session

The app does not perform brute force or exploit automation.

Use only test accounts and systems for which you have authorization.
