package com.myshort.securitytester

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {
    private lateinit var endpoint: EditText
    private lateinit var token: EditText
    private lateinit var bet: EditText
    private lateinit var output: TextView
    private lateinit var progress: ProgressBar
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val requests = AtomicInteger(0)
    private val maxRequests = 12

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(createUi())
    }

    private fun createUi(): ScrollView {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "MySlot Security Tester"
            textSize = 25f
        })
        root.addView(TextView(this).apply {
            text = "Android v3 • Authorized testing only"
            textSize = 13f
        })

        root.addView(TextView(this).apply { text = "HTTPS endpoint" })
        endpoint = EditText(this).apply {
            hint = "https://server-anda.example/api/spin"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            singleLine = true
        }
        root.addView(endpoint)

        root.addView(TextView(this).apply { text = "Bearer token akun TEST" })
        token = EditText(this).apply {
            hint = "Token (opsional)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
        }
        root.addView(token)

        root.addView(TextView(this).apply { text = "Nominal bet" })
        bet = EditText(this).apply {
            setText("1000")
            inputType = InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        root.addView(bet)

        button(root, "JALANKAN SEMUA TEST") { runTests(listOf("tamper", "replay", "auth")) }
        button(root, "TEST PARAMETER TAMPERING") { runTests(listOf("tamper")) }
        button(root, "TEST REPLAY") { runTests(listOf("replay")) }
        button(root, "TEST AUTHENTICATION") { runTests(listOf("auth")) }

        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress)

        output = TextView(this).apply {
            text = "Hasil pengujian akan tampil di sini."
            textSize = 13f
            setPadding(0, 24, 0, 24)
        }
        root.addView(output)

        root.addView(TextView(this).apply {
            text = "Gunakan hanya server yang Anda miliki/diizinkan dan akun TEST. Maksimal 12 request per sesi."
            textSize = 12f
        })

        scroll.addView(root)
        return scroll
    }

    private fun button(root: LinearLayout, text: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        })
    }

    private fun runTests(names: List<String>) {
        val target = endpoint.text.toString().trim()
        if (!target.startsWith("https://")) {
            Toast.makeText(this, "Endpoint harus HTTPS.", Toast.LENGTH_SHORT).show()
            return
        }

        requests.set(0)
        output.text = ""
        progress.visibility = View.VISIBLE

        scope.launch {
            try {
                for (name in names) {
                    when (name) {
                        "tamper" -> tamper(target)
                        "replay" -> replay(target)
                        "auth" -> authentication(target)
                    }
                }
            } catch (e: Exception) {
                append("ERROR: ${e.message}")
            } finally {
                progress.visibility = View.GONE
                append("Requests: ${requests.get()}/$maxRequests")
            }
        }
    }

    private suspend fun tamper(target: String) {
        append("\n=== PARAMETER TAMPERING ===")
        val cases = listOf(
            "win" to 100000000,
            "payout" to 100000000,
            "balance" to 999999999,
            "result" to "JACKPOT"
        )
        for ((key, value) in cases) {
            if (requests.get() >= maxRequests) break
            val body = JSONObject().put("bet", readBet()).put(key, value)
            val r = post(target, body, true)
            if (r == null) append("WARN $key: request gagal")
            else if (r.code in setOf(400, 401, 403, 409, 422))
                append("PASS $key: ditolak HTTP ${r.code}")
            else
                append("WARN $key: tidak ditolak HTTP ${r.code}; verifikasi server/database.")
        }
    }

    private suspend fun replay(target: String) {
        append("\n=== REPLAY ===")
        val body = JSONObject().put("bet", readBet())
        val first = post(target, body, true)
        val second = post(target, body, true)
        if (first == null || second == null) {
            append("WARN replay: request gagal")
        } else if (second.code == 409 || second.code == 429) {
            append("PASS replay: request kedua ditolak HTTP ${second.code}")
        } else {
            append("WARN replay: request kedua HTTP ${second.code}; periksa idempotency/replay protection.")
        }
    }

    private suspend fun authentication(target: String) {
        append("\n=== AUTHENTICATION ===")
        val r = post(target, JSONObject().put("bet", readBet()), false)
        if (r == null) append("WARN auth: request gagal")
        else if (r.code == 401 || r.code == 403)
            append("PASS auth: tanpa token ditolak HTTP ${r.code}")
        else
            append("FAIL auth: endpoint menerima request tanpa token HTTP ${r.code}")
    }

    private suspend fun post(target: String, body: JSONObject, useAuth: Boolean): ResponseData? =
        withContext(Dispatchers.IO) {
            if (requests.incrementAndGet() > maxRequests) return@withContext null
            try {
                val c = URL(target).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                c.setRequestProperty("Accept", "application/json")
                if (useAuth) {
                    val t = token.text.toString().trim()
                    if (t.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $t")
                }
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                c.disconnect()
                ResponseData(code)
            } catch (_: Exception) {
                null
            }
        }

    private fun readBet() = bet.text.toString().toLongOrNull()?.coerceAtLeast(1L) ?: 1000L

    private fun append(text: String) {
        runOnUiThread { output.append("$text\n") }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    data class ResponseData(val code: Int)
}
