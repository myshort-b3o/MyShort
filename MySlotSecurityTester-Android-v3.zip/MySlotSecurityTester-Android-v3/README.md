# MySlot Security Tester Android v3

Native Kotlin Android security tester for authorized testing of your own game API.

This V3 updates the GitHub Actions workflow for the current Node.js 24-based Actions environment.

## Build on GitHub

1. Upload the project contents to the repository.
2. Make sure `.github/workflows/build-apk.yml` exists.
3. Push to `main`, or open **Actions → Build MyShort APK → Run workflow**.
4. Wait for **Build Android APK** to become green.
5. Download artifact **MySlot-Security-Tester-v3-debug**.
6. Extract `app-debug.apk`.

The build step uses `--stacktrace --info`, so if compilation fails the actual Gradle error is visible in the log.

Use only test servers/accounts that you own or are authorized to test.
