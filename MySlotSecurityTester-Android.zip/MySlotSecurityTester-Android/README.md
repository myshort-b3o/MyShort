# MySlot Security Tester Android

Native Kotlin Android security tester for authorized testing of your own game API.

## GitHub build
Upload this folder to GitHub. Open **Actions → Build Android APK → Run workflow**.
The generated APK is available under **Artifacts**.

Tests:
- parameter tampering
- replay
- authentication

The app limits each test session to 12 requests and requires HTTPS.

Use only servers you own or are authorized to test.
