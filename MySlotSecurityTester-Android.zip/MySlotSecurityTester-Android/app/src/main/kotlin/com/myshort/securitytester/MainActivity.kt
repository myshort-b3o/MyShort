package com.myshort.securitytester

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {
    private lateinit var url: EditText
    private lateinit var token: EditText
    private lateinit var bet: EditText
    private lateinit var log: TextView
    private lateinit var progress: ProgressBar
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private val count=AtomicInteger(0)
    private val maxRequests=12

    override fun onCreate(b:Bundle?) { super.onCreate(b); setContentView(ui()) }

    private fun ui(): ScrollView {
        val s=ScrollView(this)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        fun edit(h:String)=EditText(this).apply { hint=h }
        box.addView(TextView(this).apply { text="MySlot Security Tester"; textSize=25f })
        box.addView(TextView(this).apply { text="Authorized testing only" })
        box.addView(TextView(this).apply { text="HTTPS target endpoint" })
        url=edit("https://server-anda.example/api/spin"); box.addView(url)
        box.addView(TextView(this).apply { text="Bearer token (akun TEST)" })
        token=edit("Token"); token.inputType=0x81; box.addView(token)
        box.addView(TextView(this).apply { text="Bet" })
        bet=edit("1000"); bet.setText("1000"); box.addView(bet)

        fun button(t:String, f:()->Unit)=Button(this).apply { text=t; setOnClickListener{f()}; box.addView(this) }
        button("JALANKAN SEMUA TEST"){runTests(listOf("tamper","replay","auth"))}
        button("TEST PARAMETER TAMPERING"){runTests(listOf("tamper"))}
        button("TEST REPLAY"){runTests(listOf("replay"))}
        button("TEST AUTHENTICATION"){runTests(listOf("auth"))}
        progress=ProgressBar(this); progress.visibility=ProgressBar.GONE; box.addView(progress)
        log=TextView(this).apply { text="Hasil akan tampil di sini."; setPadding(0,24,0,24) }; box.addView(log)
        box.addView(TextView(this).apply { text="Hanya gunakan server milik Anda/yang memberi izin dan akun TEST."; textSize=12f })
        s.addView(box); return s
    }

    private fun runTests(tests:List<String>) {
        val endpoint=url.text.toString().trim()
        if(!endpoint.startsWith("https://")) { toast("Gunakan HTTPS."); return }
        count.set(0); log.text=""; progress.visibility=ProgressBar.VISIBLE
        scope.launch {
            try { for(t in tests) when(t) {
                "tamper"->tamper(endpoint); "replay"->replay(endpoint); "auth"->auth(endpoint)
            }} catch(e:Exception){ out("ERROR: ${e.message}") }
            finally { progress.visibility=ProgressBar.GONE; out("Requests: ${count.get()}/$maxRequests") }
        }
    }

    private suspend fun tamper(e:String) {
        out("\n=== PARAMETER TAMPERING ===")
        listOf("win" to 100000000,"payout" to 100000000,"balance" to 999999999,"result" to "JACKPOT").forEach { (k,v)->
            if(count.get()>=maxRequests)return@forEach
            val p=JSONObject().put("bet",bet.text.toString().toLongOrNull()?:1000).put(k,v)
            val r=post(e,p,true) ?: run { out("WARN $k: request gagal"); return@forEach }
            if(r.code in listOf(400,401,403,409,422)) out("PASS $k: ditolak HTTP ${r.code}")
            else out("WARN $k: diterima HTTP ${r.code}; periksa log/database server.")
        }
    }

    private suspend fun replay(e:String) {
        out("\n=== REPLAY ===")
        val p=JSONObject().put("bet",bet.text.toString().toLongOrNull()?:1000)
        val a=post(e,p,true); val b=post(e,p,true)
        if(a==null||b==null) out("WARN replay: request gagal")
        else if(b.code==409||b.code==429) out("PASS replay: request kedua ditolak HTTP ${b.code}")
        else out("WARN replay: request kedua HTTP ${b.code}; pastikan idempotency/replay protection.")
    }

    private suspend fun auth(e:String) {
        out("\n=== AUTHENTICATION ===")
        val p=JSONObject().put("bet",bet.text.toString().toLongOrNull()?:1000)
        val r=post(e,p,false) ?: run { out("WARN auth: request gagal"); return }
        if(r.code==401||r.code==403) out("PASS auth: tanpa token ditolak HTTP ${r.code}")
        else out("FAIL auth: endpoint menerima request tanpa token HTTP ${r.code}")
    }

    private suspend fun post(e:String,p:JSONObject,auth:Boolean):Resp?=withContext(Dispatchers.IO) {
        if(count.incrementAndGet()>maxRequests)return@withContext null
        try {
            val c=URL(e).openConnection() as HttpURLConnection
            c.requestMethod="POST"; c.connectTimeout=10000; c.readTimeout=10000; c.doOutput=true
            c.setRequestProperty("Content-Type","application/json")
            if(auth&&token.text.toString().isNotBlank()) c.setRequestProperty("Authorization","Bearer ${token.text}")
            c.outputStream.use{it.write(p.toString().toByteArray())}
            val code=c.responseCode
            c.disconnect()
            Resp(code)
        } catch(_:Exception){null}
    }

    private fun out(t:String){runOnUiThread{log.append("$t\n")}}
    private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()
    override fun onDestroy(){scope.cancel();super.onDestroy()}
    data class Resp(val code:Int)
}
